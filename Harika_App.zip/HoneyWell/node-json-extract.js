const data = require('SampleJson');

console.log(data);

const fs = require('fs');
fs.readFile("SampleJson.json", function(err, data) {
    if(err) throw err;

    const items = JSON.parse(data);
    console.log(items);

    fs.writeFile("SampleJson.json", data, callback);

})